# Set nested values

## What it does
This sets the value of a nested element of a dictionary (for example
coming from a TOML configuration file)

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues