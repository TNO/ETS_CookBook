# Query list from file

## What it does
This returns a list of queries from an SQL file


## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues