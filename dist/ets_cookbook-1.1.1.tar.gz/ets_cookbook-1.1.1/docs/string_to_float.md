# String to float

## What it does
Converts strings to floats, and to zero if the string is not a float.
   

## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues