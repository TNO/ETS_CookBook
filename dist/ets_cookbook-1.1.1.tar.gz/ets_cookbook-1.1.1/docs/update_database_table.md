# Update database table

## What it does
This function updates the values
of one row of a table in a database.
If you want to change multiple rows (with
a different value for each row), then you need to iterate over the rows.
    
## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues