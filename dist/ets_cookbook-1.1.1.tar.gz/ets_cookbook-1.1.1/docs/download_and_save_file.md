# Download and save file

## What it does
Downloads a file from an URL and saves it. If the file is a zip file,
the function extracts its contents.
## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues