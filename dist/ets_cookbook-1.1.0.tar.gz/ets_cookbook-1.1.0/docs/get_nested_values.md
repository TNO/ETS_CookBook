# Get nested values

## What it does
If you give a dictionary (for example a TOML configuration file)
    and a list of nested keys, this returns the desired value.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues