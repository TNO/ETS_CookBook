# Check if folder exists

## What it 

Checks if a folder exists. If it does not, it creates it.
This way, users can set up a new (sub-)folder in the configuration file
without having to ensure that it already exits or create it.

## Inputs
### folder_to_check
This is a string with the name of a folder

## Output
This function has no output (but creates a folder if it does not exist).

## Examples

###

## Tests

###


## Open issues