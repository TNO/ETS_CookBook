# Save figure

## What it does
This function saves a Matplolib figure to a number of
file formats and an output folder that are all specified in a
TOML parameters file (under a [files.figures_outputs] heading).

(Use something more explicit than parameters)
## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues