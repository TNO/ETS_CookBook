# Read table from database

## What it does
Reads a table from an SQLite3 database and returns it as a DataFrame.
## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues