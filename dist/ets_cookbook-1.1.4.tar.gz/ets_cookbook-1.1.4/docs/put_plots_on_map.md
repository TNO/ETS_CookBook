# Put plots on map

## What it does

Puts plots/Axes on a map figure. You can then draw in these.
The plot_y_total_values are the sizes of the plots per country (for example
the size of the stacked bar for a stacked bar plot).

## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues