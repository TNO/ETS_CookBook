# Get extra colors

## What it does
This function gets the user-defined extra colors from a file.
This file contains the names of the colors, and their RGB values
(from 0 to 255). The function returns a DataFrame with
color names as index, and their RGB codes (between 0 and 1)
as values.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues