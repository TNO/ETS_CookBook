# Delete Word element

## What it does
Deletes a given element in a Word document.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues