# RGBA code color

## What it does
Gets an RGBA string from a color RGB tuple.
This is useful for plotly.
The A part is the color opacity.
    

## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues