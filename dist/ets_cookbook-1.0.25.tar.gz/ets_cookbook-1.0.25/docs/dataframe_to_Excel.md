# DataFrame to Excel

## What it does
  
This function takes a DataFrame and puts it into a new sheet in
an Excel workbook. If the sheet already exists, it will replace it.
If the Excel workbook does not exist, the function creates it.
    
## Inputs
### dataframe_to_append
### Excel_workbook
### my_sheet

## Output

###

## Examples

###

## Tests

###


## Open issues