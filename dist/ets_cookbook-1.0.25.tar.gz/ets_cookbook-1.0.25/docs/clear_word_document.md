# Clear Word document

## What it does
Clears a Word document of its elements
(text/paragraphs, tables, pictures.)
    

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues