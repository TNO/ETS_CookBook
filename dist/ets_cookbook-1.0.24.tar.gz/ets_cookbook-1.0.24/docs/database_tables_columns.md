# Database tables columns

## What it does

Returns a dictionary with the tables of a database as keys and their
columns as values.
   

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues