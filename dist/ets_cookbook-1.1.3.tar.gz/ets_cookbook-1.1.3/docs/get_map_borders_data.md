# Get map borders

## What it does

This function gets the borders/contours of regions at a specified NUTS
level.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues