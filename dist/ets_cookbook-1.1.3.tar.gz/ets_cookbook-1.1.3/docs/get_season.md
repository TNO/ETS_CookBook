# Get season

## What it does

This function takes a datetime timestamp and tells us in which season
it is.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues