# RGB color list

## What it does

Gets a list of RGB codes for a list of color names.


## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues