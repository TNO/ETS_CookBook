# Get RGB 255 code string

## What it does

Creates a string with rgb values (0-255),
rgb(111, 233, 66)
This is used for plotly.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues