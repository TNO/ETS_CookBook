# Get RGB from name
## What it does

This function takes a color name and returns its RGB values (0 to 1).
If the color name is in the extra colors, then, we use
the values given.
If it is a matplotlib color, then we use the matplotlib function.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues