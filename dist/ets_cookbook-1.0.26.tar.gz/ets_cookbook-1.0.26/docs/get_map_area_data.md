# Get map area data

## What it does
This function gets and processes the area data and sets it
into a DataFrame. It contains polygons/multipolygons
(they are at a given granularity level, but also have references to higher
levels).
    
## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues