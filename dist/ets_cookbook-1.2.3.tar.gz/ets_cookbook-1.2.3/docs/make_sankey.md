# Make Sankey

## What it does
Makes a Sankey plot in plotly (comes out as an html file).
The nodes and links are in a DataFrame.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues