# From grib to DataFrame

## What it does
This function takes a grib file and converts it to a DataFrame.
**Important note:**
You need to have ecmwflibs installed for the grib converter to work.
Installing xarray (and cfrgrib to have the right engine) is not enough!
See:
https://github.com/ecmwf/eccodes-python/issues/54#issuecomment-925036724

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues

### installed libraries
You need to have ecmwflibs installed for the grib converter to work.
Installing xarray (and cfrgrib to have the right engine) is not enough!
See:
https://github.com/ecmwf/eccodes-python/issues/54#issuecomment-925036724