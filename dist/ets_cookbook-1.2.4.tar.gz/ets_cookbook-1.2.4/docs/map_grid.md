# Map grid

## What it does

This function creates a grid of maps. You need to give it the data you want
to plot, the names of the quantities, and their colors, as well as
some plot parameters (in your general parameters file, under
a [map_grid_plot]  header). You also need to have a map areas data file
such as this one:
https://www.naturalearthdata.com/http//www.naturalearthdata.com/download/110m/cultural/ne_110m_admin_0_countries.zip
You also need to provide a csv file that translates the names of the
countries you are using into ISOA3 codes, which can be found here
https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3



## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues
