# Make cell text vertical

## What it does


Changes the orientation of a Word table cell to vertical,
with the option to get text from bottom to top (default)
or top to bottom (set the optional bottom_to_top argument to True)
See
https://stackoverflow.com/questions/47738013/how-to-rotate-text-in-table-cells
for a breakdown


## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues