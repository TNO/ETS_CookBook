# Make query filter

## What it does
Returns a query filter string that can be used in an SQL query.

## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues
