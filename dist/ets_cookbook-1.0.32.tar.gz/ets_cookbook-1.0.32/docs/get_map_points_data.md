# Get map points

## What it does

This function gets the points/labels of regions at a specified NUTS
level.
## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues