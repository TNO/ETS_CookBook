# Put DataFrame in SQL in chunks

## What it does

This function takes a DataFrame and writes it into the table
of an SQL database. It does so in chunks to avoid memory issues.
The parameter drop_existing table tells us if we want to
drop/overwrite the table if it exists (it is True by default).
If set to False, the data will be appended (if the table exists).


## Inputs
###

## Output

###

## Examples

###

## Tests

###

## Open issues