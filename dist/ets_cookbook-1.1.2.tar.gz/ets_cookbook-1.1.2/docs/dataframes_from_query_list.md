# DataFrames from query list

## What it does
This returns a list of DataFrames, each obtained from a query in the list


## Inputs
###

## Output

###

## Examples

###

## Tests

###


## Open issues